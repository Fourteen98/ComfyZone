import { Link, usePage } from '@inertiajs/react'
import type { ReactNode } from 'react'

// The frame around every logged-in page: top bar, flash messages, content.
export default function AppLayout({ children }: { children: ReactNode }) {
  // usePage() is how any component reaches the data Rails sent.
  // `props.auth` comes from inertia_share; `flash` from Rails' flash.
  const { props, flash } = usePage()
  const user = props.auth.user

  return (
    <div className="min-h-screen bg-stone-50 text-stone-900">
      <header className="border-b border-stone-200 bg-white">
        <div className="mx-auto flex max-w-3xl items-center justify-between px-4 py-3">
          <Link href="/" className="text-lg font-semibold tracking-tight">
            ComfyZone
          </Link>

          {user && (
            <div className="flex items-center gap-3 text-sm">
              <span className="hidden text-stone-500 sm:inline">{user.email_address}</span>
              {/* A Link with method="delete" sends DELETE /session, which
                  Rails routes to SessionsController#destroy. */}
              <Link
                href="/session"
                method="delete"
                as="button"
                className="rounded-md border border-stone-300 px-3 py-1.5 font-medium hover:bg-stone-100"
              >
                Log out
              </Link>
            </div>
          )}
        </div>
      </header>

      <main className="mx-auto max-w-3xl px-4 py-6">
        {flash.notice && (
          <p className="mb-4 rounded-md bg-emerald-50 px-3 py-2 text-sm text-emerald-800">{flash.notice}</p>
        )}
        {flash.alert && (
          <p className="mb-4 rounded-md bg-red-50 px-3 py-2 text-sm text-red-800">{flash.alert}</p>
        )}
        {children}
      </main>
    </div>
  )
}
