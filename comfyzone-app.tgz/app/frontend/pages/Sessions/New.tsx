import { Head, useForm, usePage } from '@inertiajs/react'
import type { FormEvent } from 'react'

export default function NewSession() {
  const { flash } = usePage()

  // useForm holds the field values, sends them to Rails, and collects any
  // validation errors Rails sends back. It replaces `form_with` from ERB.
  const form = useForm({
    email_address: '',
    password: '',
  })

  function submit(event: FormEvent) {
    event.preventDefault()
    // POST /session -> SessionsController#create.
    // The CSRF token is attached automatically.
    form.post('/session', {
      // Never keep a typed password on screen after a failed attempt.
      onError: () => form.reset('password'),
    })
  }

  return (
    <div className="flex min-h-screen items-center justify-center bg-stone-50 px-4 text-stone-900">
      <Head title="Log in" />

      <div className="w-full max-w-sm">
        <h1 className="text-center text-2xl font-semibold tracking-tight">ComfyZone</h1>
        <p className="mt-1 text-center text-sm text-stone-500">Log in to manage stock and sales</p>

        {flash.alert && (
          <p className="mt-4 rounded-md bg-red-50 px-3 py-2 text-sm text-red-800">{flash.alert}</p>
        )}
        {flash.notice && (
          <p className="mt-4 rounded-md bg-emerald-50 px-3 py-2 text-sm text-emerald-800">{flash.notice}</p>
        )}

        <form onSubmit={submit} className="mt-6 space-y-4 rounded-lg border border-stone-200 bg-white p-5">
          <div>
            <label htmlFor="email_address" className="block text-sm font-medium">
              Email
            </label>
            <input
              id="email_address"
              type="email"
              required
              autoFocus
              autoComplete="username"
              value={form.data.email_address}
              onChange={(e) => form.setData('email_address', e.target.value)}
              className="mt-1 block w-full rounded-md border-stone-300 text-base"
            />
            {/* Set by `inertia: { errors: ... }` in SessionsController#create */}
            {form.errors.email_address && (
              <p className="mt-1 text-sm text-red-700">{form.errors.email_address}</p>
            )}
          </div>

          <div>
            <label htmlFor="password" className="block text-sm font-medium">
              Password
            </label>
            <input
              id="password"
              type="password"
              required
              maxLength={72}
              autoComplete="current-password"
              value={form.data.password}
              onChange={(e) => form.setData('password', e.target.value)}
              className="mt-1 block w-full rounded-md border-stone-300 text-base"
            />
          </div>

          <button
            type="submit"
            disabled={form.processing}
            className="w-full rounded-md bg-stone-900 px-4 py-2.5 font-medium text-white hover:bg-stone-800 disabled:opacity-60"
          >
            {form.processing ? 'Logging in…' : 'Log in'}
          </button>
        </form>

        {/* A plain <a>, not <Link>: the password reset pages are still
            classic Rails ERB views, so we want a normal full page load. */}
        <p className="mt-4 text-center text-sm">
          <a href="/passwords/new" className="text-stone-600 underline hover:text-stone-900">
            Forgot password?
          </a>
        </p>
      </div>
    </div>
  )
}
