import { Head } from '@inertiajs/react'
import AppLayout from '@/layouts/AppLayout'

// These props are exactly the hash passed to `render inertia: "Dashboard",
// props: { ... }` in DashboardController#show.
type Props = {
  today: string
}

const comingNext = [
  { title: 'Products', body: 'What she sells, with photos and prices.' },
  { title: 'Purchases', body: 'Restocks from suppliers, with true cost per item.' },
  { title: 'Stock', body: 'What is on hand right now, and what is running low.' },
  { title: 'Live sales', body: 'Fast order capture during a TikTok live.' },
]

export default function Dashboard({ today }: Props) {
  return (
    <AppLayout>
      {/* <Head> sets the browser tab title for this page. */}
      <Head title="Dashboard" />

      <p className="text-sm text-stone-500">{today}</p>
      <h1 className="mt-1 text-2xl font-semibold tracking-tight">Dashboard</h1>
      <p className="mt-2 text-stone-600">
        The foundation is running. These sections get built next, in this order:
      </p>

      <ol className="mt-6 grid gap-3 sm:grid-cols-2">
        {comingNext.map((item, index) => (
          <li key={item.title} className="rounded-lg border border-stone-200 bg-white p-4">
            <p className="text-xs font-medium text-stone-400">Step {index + 1}</p>
            <p className="mt-1 font-medium">{item.title}</p>
            <p className="mt-1 text-sm text-stone-600">{item.body}</p>
          </li>
        ))}
      </ol>
    </AppLayout>
  )
}
