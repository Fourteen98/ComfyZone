# Parent class for every controller that renders a React page.
#
# `inertia_share` adds props to EVERY page automatically, so each controller
# doesn't have to repeat them. The block runs once per request.
# On the React side these arrive through `usePage().props`.
class InertiaController < ApplicationController
  inertia_share do
    {
      auth: {
        # Current.user is set by the Authentication concern once someone is
        # logged in. Only send the fields React needs, never the whole record
        # (it would include password_digest).
        user: Current.user&.slice(:id, :email_address)
      }
    }
  end
end
