class DashboardController < InertiaController
  # GET /
  #
  # `render inertia:` is the one new idea compared to classic Rails.
  # Instead of rendering app/views/dashboard/show.html.erb, it tells the
  # browser: "show the React component at app/frontend/pages/Dashboard.tsx
  # and hand it these props".
  def show
    render inertia: "Dashboard", props: {
      today: Date.current.strftime("%A, %-d %B %Y")
    }
  end
end
