# Run with `bin/rails db:seed` (also runs as part of `bin/rails db:setup`).
#
# Creates a first login for local development. `find_or_create_by!` makes it
# safe to run more than once. Change the password before using real data.
if Rails.env.development?
  User.find_or_create_by!(email_address: "owner@comfyzone.test") do |user|
    user.password = "password"
  end
  puts "Dev login: owner@comfyzone.test / password"
end
