require "test_helper"

class DashboardControllerTest < ActionDispatch::IntegrationTest
  test "sends visitors who are not logged in to the login page" do
    get root_path

    assert_redirected_to new_session_path
  end

  test "renders the Dashboard React page for a logged-in user" do
    user = users(:one)
    sign_in_as(user)

    get root_path

    assert_response :success
    # Which React component did the controller ask for?
    assert_inertia_component "Dashboard"
    # Shared props from InertiaController reach the page...
    assert_inertia_props auth: { user: { id: user.id, email_address: user.email_address } }
    # ...and the password hash never does.
    assert_not_includes response.body, user.password_digest
  end
end
